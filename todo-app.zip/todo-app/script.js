document.addEventListener('DOMContentLoaded', () => {
    // Selectors
    const itemForm = document.getElementById('item-form');
    const titleInput = document.getElementById('item-title');
    const bodyInput = document.getElementById('item-body');
    const editIdInput = document.getElementById('edit-id');
    const submitBtn = document.getElementById('submit-btn');
    const cancelEditBtn = document.getElementById('cancel-edit-btn');
    
    const itemList = document.getElementById('item-list');
    const emptyState = document.getElementById('empty-state');
    const totalItemsSpan = document.getElementById('total-items');
    const completedItemsSpan = document.getElementById('completed-items');
    const clearAllBtn = document.getElementById('clear-all-btn');

    // State
    let items = JSON.parse(localStorage.getItem('notes_tasks')) || [];

    // Initialize
    renderItems();

    // Event Listeners
    itemForm.addEventListener('submit', handleFormSubmit);
    cancelEditBtn.addEventListener('click', resetForm);
    clearAllBtn.addEventListener('click', handleClearAll);

    // Functions
    function saveToLocalStorage() {
        localStorage.setItem('notes_tasks', JSON.stringify(items));
    }

    function handleFormSubmit(e) {
        e.preventDefault();

        const title = titleInput.value.trim();
        const body = bodyInput.value.trim();
        const editId = editIdInput.value;

        if (!title) return;

        if (editId) {
            // Editing existing item
            const index = items.findIndex(item => item.id === editId);
            if (index !== -1) {
                items[index].title = title;
                items[index].body = body;
            }
        } else {
            // Adding new item
            const newItem = {
                id: Date.now().toString(),
                title: title,
                body: body,
                completed: false,
                timestamp: new Date().toISOString()
            };
            items.unshift(newItem); // Add to beginning
        }

        saveToLocalStorage();
        renderItems();
        resetForm();
    }

    function resetForm() {
        itemForm.reset();
        editIdInput.value = '';
        submitBtn.textContent = 'Add Note';
        cancelEditBtn.classList.add('hidden');
    }

    function handleEdit(id) {
        const item = items.find(i => i.id === id);
        if (item) {
            titleInput.value = item.title;
            bodyInput.value = item.body;
            editIdInput.value = item.id;
            submitBtn.textContent = 'Update Note';
            cancelEditBtn.classList.remove('hidden');
            
            // Scroll to form
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    }

    function handleToggleComplete(id) {
        const index = items.findIndex(item => item.id === id);
        if (index !== -1) {
            items[index].completed = !items[index].completed;
            saveToLocalStorage();
            renderItems();
        }
    }

    function handleDelete(id) {
        if (confirm('Are you sure you want to delete this item?')) {
            items = items.filter(item => item.id !== id);
            saveToLocalStorage();
            renderItems();
            
            // If deleting the item currently being edited
            if (editIdInput.value === id) {
                resetForm();
            }
        }
    }

    function handleClearAll() {
        if (items.length === 0) return;
        
        if (confirm('Are you sure you want to delete ALL items? This action cannot be undone.')) {
            items = [];
            saveToLocalStorage();
            renderItems();
            resetForm();
        }
    }

    function formatTimestamp(isoString) {
        const date = new Date(isoString);
        return date.toLocaleString(undefined, { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    function updateStats() {
        const total = items.length;
        const completed = items.filter(item => item.completed).length;
        
        totalItemsSpan.textContent = `Total: ${total}`;
        completedItemsSpan.textContent = `Completed: ${completed}`;
        
        if (total === 0) {
            emptyState.classList.remove('hidden');
            itemList.classList.add('hidden');
        } else {
            emptyState.classList.add('hidden');
            itemList.classList.remove('hidden');
        }
    }

    // Render Function
    function renderItems() {
        itemList.innerHTML = '';

        items.forEach(item => {
            const li = document.createElement('li');
            li.className = `list-item ${item.completed ? 'completed' : ''}`;
            li.dataset.id = item.id;

            // Icons (SVG)
            const checkIcon = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>`;
            const editIcon = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" /></svg>`;
            const deleteIcon = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" /></svg>`;
            const timeIcon = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>`;

            li.innerHTML = `
                <div class="item-content">
                    <h3 class="item-title">${item.title}</h3>
                    ${item.body ? `<p class="item-body">${item.body}</p>` : ''}
                    <div class="item-timestamp">
                        ${timeIcon}
                        <span>${formatTimestamp(item.timestamp)}</span>
                    </div>
                </div>
                <div class="item-actions">
                    <button class="icon-btn complete" aria-label="Toggle Complete">
                        ${checkIcon}
                    </button>
                    <button class="icon-btn edit" aria-label="Edit Item">
                        ${editIcon}
                    </button>
                    <button class="icon-btn delete" aria-label="Delete Item">
                        ${deleteIcon}
                    </button>
                </div>
            `;

            // Attach specific event listeners to buttons
            const completeBtn = li.querySelector('.complete');
            const editBtn = li.querySelector('.edit');
            const deleteBtn = li.querySelector('.delete');

            completeBtn.addEventListener('click', () => handleToggleComplete(item.id));
            editBtn.addEventListener('click', () => handleEdit(item.id));
            deleteBtn.addEventListener('click', () => handleDelete(item.id));

            itemList.appendChild(li);
        });

        updateStats();
    }
});
