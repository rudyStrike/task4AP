document.addEventListener('DOMContentLoaded', () => {
    // Product Dataset (12 items)
    const products = [
        { id: 1, name: 'MacBook Pro 16"', category: 'Laptops', price: 2499, rating: 4.9, image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=600&q=80' },
        { id: 2, name: 'Dell XPS 13', category: 'Laptops', price: 1299, rating: 4.7, image: 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?auto=format&fit=crop&w=600&q=80' },
        { id: 3, name: 'Sony WH-1000XM5', category: 'Audio', price: 398, rating: 4.8, image: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?auto=format&fit=crop&w=600&q=80' },
        { id: 4, name: 'Apple AirPods Pro', category: 'Audio', price: 249, rating: 4.6, image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?auto=format&fit=crop&w=600&q=80' },
        { id: 5, name: 'Logitech MX Master 3', category: 'Accessories', price: 99, rating: 4.9, image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=600&q=80' },
        { id: 6, name: 'Keychron K2 Keyboard', category: 'Accessories', price: 89, rating: 4.5, image: 'https://images.unsplash.com/photo-1595225476474-87563907a212?auto=format&fit=crop&w=600&q=80' },
        { id: 7, name: 'Asus ROG Zephyrus', category: 'Laptops', price: 1899, rating: 4.6, image: 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?auto=format&fit=crop&w=600&q=80' },
        { id: 8, name: 'Bose QuietComfort 45', category: 'Audio', price: 329, rating: 4.7, image: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=600&q=80' },
        { id: 9, name: 'LG 34" Ultrawide Monitor', category: 'Accessories', price: 799, rating: 4.8, image: 'https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc?auto=format&fit=crop&w=600&q=80' },
        { id: 10, name: 'Samsung Galaxy Buds 2', category: 'Audio', price: 149, rating: 4.4, image: 'https://images.unsplash.com/photo-1606220838315-056192d5e92b?auto=format&fit=crop&w=600&q=80' },
        { id: 11, name: 'Razer DeathAdder V2', category: 'Accessories', price: 69, rating: 4.5, image: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?auto=format&fit=crop&w=600&q=80' },
        { id: 12, name: 'Lenovo ThinkPad X1', category: 'Laptops', price: 1499, rating: 4.7, image: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=600&q=80' }
    ];

    // State
    let currentCategory = 'All';
    let currentMaxPrice = 3000;
    let currentSort = 'default';

    // Selectors
    const productGrid = document.getElementById('product-grid');
    const categoryBtns = document.querySelectorAll('.filter-btn');
    const priceRange = document.getElementById('price-range');
    const priceDisplay = document.getElementById('price-display');
    const sortSelect = document.getElementById('sort-select');
    const resetBtn = document.getElementById('reset-btn');
    const noResults = document.getElementById('no-results');
    const resultsCount = document.getElementById('results-count');

    // SVG Icons
    const starIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>`;

    // Initial Render
    filterAndRender();

    // Event Listeners
    categoryBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Update active class
            categoryBtns.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            
            // Update state and render
            currentCategory = e.target.dataset.category;
            filterAndRender();
        });
    });

    priceRange.addEventListener('input', (e) => {
        currentMaxPrice = parseInt(e.target.value);
        priceDisplay.textContent = currentMaxPrice;
        filterAndRender();
    });

    sortSelect.addEventListener('change', (e) => {
        currentSort = e.target.value;
        filterAndRender();
    });

    resetBtn.addEventListener('click', () => {
        // Reset State
        currentCategory = 'All';
        currentMaxPrice = 3000;
        currentSort = 'default';
        
        // Reset UI
        categoryBtns.forEach(b => b.classList.remove('active'));
        document.querySelector('[data-category="All"]').classList.add('active');
        priceRange.value = 3000;
        priceDisplay.textContent = '3000';
        sortSelect.value = 'default';
        
        filterAndRender();
    });

    // Core Logic
    function filterAndRender() {
        // 1. Filter
        let filteredProducts = products.filter(product => {
            const matchesCategory = currentCategory === 'All' || product.category === currentCategory;
            const matchesPrice = product.price <= currentMaxPrice;
            return matchesCategory && matchesPrice;
        });

        // 2. Sort
        if (currentSort === 'price-asc') {
            filteredProducts.sort((a, b) => a.price - b.price);
        } else if (currentSort === 'price-desc') {
            filteredProducts.sort((a, b) => b.price - a.price);
        } else if (currentSort === 'rating-desc') {
            filteredProducts.sort((a, b) => b.rating - a.rating);
        }
        // 'default' implies original array order, which is roughly maintained or sorted by id implicitly here

        // 3. Render
        renderProducts(filteredProducts);
    }

    function renderProducts(itemsToRender) {
        // Update count
        resultsCount.textContent = itemsToRender.length;

        // Clear grid
        productGrid.innerHTML = '';

        if (itemsToRender.length === 0) {
            productGrid.classList.add('hidden');
            noResults.classList.remove('hidden');
            return;
        }

        productGrid.classList.remove('hidden');
        noResults.classList.add('hidden');

        // Create cards
        itemsToRender.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            
            card.innerHTML = `
                <div class="product-img">
                    <img src="${product.image}" alt="${product.name}">
                </div>
                <div class="product-info">
                    <span class="product-category">${product.category}</span>
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-meta">
                        <span class="product-price">$${product.price}</span>
                        <div class="product-rating">
                            ${starIcon}
                            <span>${product.rating}</span>
                        </div>
                    </div>
                </div>
            `;
            
            productGrid.appendChild(card);
        });
    }
});
